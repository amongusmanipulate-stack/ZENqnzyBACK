package com.retrivedmods.wrelay.config

data class EnhancedServerConfig(
    val maxRetryAttempts: Int = 8,
    val initialRetryDelay: Long = 1500L,
    val maxRetryDelay: Long = 25000L,
    val backoffMultiplier: Double = 1.7,
    val connectionTimeout: Long = 35000L,
    val sessionTimeout: Long = 60000L,
    val timeBetweenConnectionAttempts: Long = 1800L,
    val compatibilityMode: Boolean = true,
    val initialConnectionDelay: Long = 400L,
    val enableConnectionThrottling: Boolean = true,
    val connectionThrottleDelay: Long = 2500L,
    val mtu: Int = 1400,
    val enableKeepAlive: Boolean = true,
    val keepAliveIntervalMs: Long = 10000L,
    val maxSilentMs: Long = 45000L
) {
    companion object {
        val DEFAULT = EnhancedServerConfig()

        val STABLE = EnhancedServerConfig(
            maxRetryAttempts = 10,
            initialRetryDelay = 2000L,
            maxRetryDelay = 40000L,
            backoffMultiplier = 1.8,
            connectionTimeout = 45000L,
            sessionTimeout = 90000L,
            timeBetweenConnectionAttempts = 2200L,
            initialConnectionDelay = 600L,
            connectionThrottleDelay = 4000L,
            mtu = 1200,
            enableKeepAlive = true,
            keepAliveIntervalMs = 8000L,
            maxSilentMs = 60000L
        )

        val AGGRESSIVE = EnhancedServerConfig(
            maxRetryAttempts = 12,
            initialRetryDelay = 2500L,
            maxRetryDelay = 60000L,
            backoffMultiplier = 2.0,
            connectionTimeout = 50000L,
            sessionTimeout = 90000L,
            timeBetweenConnectionAttempts = 2500L,
            initialConnectionDelay = 1500L,
            connectionThrottleDelay = 6000L,
            mtu = 1200
        )

        val FAST = EnhancedServerConfig(
            maxRetryAttempts = 4,
            initialRetryDelay = 800L,
            maxRetryDelay = 8000L,
            backoffMultiplier = 1.4,
            connectionTimeout = 18000L,
            sessionTimeout = 30000L,
            timeBetweenConnectionAttempts = 1000L,
            initialConnectionDelay = 150L,
            connectionThrottleDelay = 1200L,
            mtu = 1400
        )
    }

    fun calculateRetryDelay(attemptNumber: Int): Long {
        val jitter = (Math.random() * 400).toLong()
        val delay = (initialRetryDelay * Math.pow(backoffMultiplier, attemptNumber.toDouble())).toLong() + jitter
        return minOf(delay, maxRetryDelay)
    }

    fun isProtectedServer(hostname: String): Boolean {
        val h = hostname.lowercase()
        return h.contains("aternos") || h.contains("minehut") || h.contains("server.pro") ||
                h.contains("shockbyte") || h.contains("apexminecrafthosting")
    }
}
