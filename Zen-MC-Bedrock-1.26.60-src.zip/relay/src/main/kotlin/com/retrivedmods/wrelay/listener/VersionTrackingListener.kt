package com.retrivedmods.wrelay.listener

import com.retrivedmods.wrelay.codec.VersionInfoProvider
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket
import org.cloudburstmc.protocol.bedrock.packet.RequestNetworkSettingsPacket

class VersionTrackingListener(
    private val onVersionDetected: (protocolVersion: Int, minecraftVersion: String) -> Unit = { _, _ -> }
) : WRelayPacketListener {

    private var versionDetected = false

    override fun beforeClientBound(packet: BedrockPacket): Boolean {
        if (!versionDetected && packet is RequestNetworkSettingsPacket) {
            val protocolVersion = packet.protocolVersion
            val versionInfo = VersionInfoProvider.getVersionInfo(protocolVersion)

            if (!versionInfo.isExactMatch) {
                println(
                    "[ZenRelay] WARN: Protocol $protocolVersion has no native codec – using closest " +
                    "${versionInfo.codec.protocolVersion} (${versionInfo.minecraftVersion}). " +
                    "Some packets/modules may be limited on 1.26.x until a full codec is added."
                )
            } else {
                println("[ZenRelay] Exact codec match: $versionInfo")
            }

            onVersionDetected(protocolVersion, versionInfo.minecraftVersion)
            versionDetected = true
        }
        return false
    }
}
